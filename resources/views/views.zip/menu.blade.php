<div class="col-md-12 col-panel3">
                        <div class="row row-panel3">
                            <div class="col-lg-3 col-md-3 col-panel1 col-xl-3">
                                <ul class="list-group">
                                    <li class="active1 list-group-item">Rifas</li>
                                    <a href="{{route('rifas.create')}}"><li class="list-group-item list-hover list1 text-dark">Crear Rifa</li></a>
                                    <a href="{{route('rifas.index')}}"><li class="list-group-item list-hover list1 text-dark">Registros de rifa</li></a>
                                </ul>                                 
                            </div> 
                            <div class="col-lg-3 col-md-3 col-panel1 col-xl-3">
                                <ul class="list-group">
                                    <li class="active1 list-group-item">Boletos</li>
                                    <a href="{{route('boletos.index')}}"><li class="list-group-item list-hover list1 text-dark">Registro de Boletos</li></a>
                                    <a href="{{route('bonos.index')}}"><li class="list-group-item list-hover list1 text-dark">Bonos</li></a>
                                    
                                </ul>                                 
                            </div>
                            <div class="col-lg-3 col-md-3 col-panel1 col-xl-3">
                                <ul class="list-group">
                                    <li class="active1 list-group-item">Gestión Comunicacional</li>
                                    <a href="{{route('pagos.index')}}"><li class="list-group-item list-hover list1 text-dark">Datos Bancarios</li></a>
                                    <a href="{{route('promocionals.index')}}"><li class="list-group-item list-hover list1 text-dark">Codigos Promocional </li></a>
                                </ul>                                 
                            </div>
                        </div>                         
                    </div>